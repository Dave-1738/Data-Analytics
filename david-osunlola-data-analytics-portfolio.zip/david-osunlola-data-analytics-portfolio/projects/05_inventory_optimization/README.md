# 05 · Inventory & Replenishment

## Business question
Which SKUs contribute most to annual demand value, and which may need replenishment attention based on recent sales, stock on hand, and supplier lead time?

## Dataset
`data/inventory_monthly.csv` contains synthetic monthly demand and ending stock for 30 fictional SKUs during 2025.

| Field | Description |
|---|---|
| `sku` | Synthetic stock-keeping unit |
| `month` | Reporting month |
| `units_sold` | Units sold during the month |
| `ending_on_hand` | Units on hand at month end |
| `unit_cost` | Synthetic unit cost |
| `lead_time_days` | Synthetic replenishment lead time |

## Metrics and method
Annual demand value = units sold × unit cost, summed by SKU. ABC class is assigned by cumulative share of demand value (A through 80%, B through 95%, C thereafter). A rough days-of-cover indicator divides current ending stock by average daily demand (based on the included 12-month history). The replenishment flag compares days of cover with supplier lead time plus a 7-day illustrative buffer.

## Run
From the repository root: `python projects/05_inventory_optimization/analysis.py`

Outputs include SKU classification, replenishment review, category summary, and a value chart. SQL examples are in `sql/`.

## Limitations
This simplified rule ignores demand variability, service-level targets, order minimums, seasonality, open purchase orders, supplier calendars, and stockouts. The 7-day buffer is illustrative, not an operational recommendation. Confirm formulas with inventory owners before applying them.
