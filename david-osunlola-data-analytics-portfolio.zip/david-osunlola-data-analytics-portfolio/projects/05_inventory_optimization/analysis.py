"""ABC inventory and simple stock-cover review using synthetic sample data."""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

PROJECT = Path(__file__).resolve().parent
DATA = PROJECT / "data" / "inventory_monthly.csv"
OUT = PROJECT / "outputs"


def main():
    df = pd.read_csv(DATA, parse_dates=["month"])
    required = {"sku", "month", "units_sold", "ending_on_hand", "unit_cost", "lead_time_days"}
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")
    if df[["units_sold", "ending_on_hand", "unit_cost", "lead_time_days"]].lt(0).any().any():
        raise ValueError("Inventory measures cannot be negative.")
    df["demand_value"] = df.units_sold * df.unit_cost
    latest = df.sort_values("month").groupby("sku", as_index=False).tail(1).set_index("sku")
    summary = df.groupby("sku").agg(annual_units=("units_sold", "sum"), annual_demand_value=("demand_value", "sum"), avg_monthly_units=("units_sold", "mean"), unit_cost=("unit_cost", "last"), lead_time_days=("lead_time_days", "last"))
    summary["ending_on_hand"] = latest.ending_on_hand
    summary["days_of_cover"] = summary.ending_on_hand.div(summary.avg_monthly_units.where(summary.avg_monthly_units.ne(0))) * 30.44
    summary = summary.sort_values("annual_demand_value", ascending=False)
    summary["cumulative_value_share"] = summary.annual_demand_value.cumsum() / summary.annual_demand_value.sum()
    summary["abc_class"] = summary.cumulative_value_share.map(lambda x: "A" if x <= .80 else ("B" if x <= .95 else "C"))
    summary["replenishment_review"] = summary.days_of_cover < (summary.lead_time_days + 7)
    OUT.mkdir(exist_ok=True)
    summary.reset_index().to_csv(OUT / "sku_inventory_review.csv", index=False, float_format="%.2f")
    summary.reset_index().query("replenishment_review").to_csv(OUT / "replenishment_review.csv", index=False, float_format="%.2f")
    summary.groupby("abc_class", as_index=False).agg(skus=("annual_units", "count"), annual_units=("annual_units", "sum"), annual_demand_value=("annual_demand_value", "sum")).to_csv(OUT / "abc_summary.csv", index=False, float_format="%.2f")
    ax = summary.head(12).sort_values("annual_demand_value").annual_demand_value.plot(kind="barh", figsize=(8, 6), title="Top 12 SKUs by annual demand value")
    ax.set_xlabel("Demand value (currency units)"); ax.set_ylabel("SKU"); ax.grid(axis="x", alpha=.25)
    plt.tight_layout(); plt.savefig(OUT / "top_sku_demand_value.png", dpi=160); plt.close()
    print(f"Reviewed {len(summary)} synthetic SKUs. Outputs: {OUT}")

if __name__ == "__main__":
    main()
