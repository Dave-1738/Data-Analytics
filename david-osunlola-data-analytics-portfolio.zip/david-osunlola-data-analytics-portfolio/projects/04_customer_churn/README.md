# 04 · Customer Churn & Retention

## Business question
How does churn vary across contract type, tenure, internet service, monthly charges, and recent support contacts?

## Dataset
`data/customers.csv` contains 300 synthetic customer records with a binary churn label. The data are generated for demonstration and are not sourced from a telecom provider.

| Field | Description |
|---|---|
| `customer_id` | Synthetic customer key |
| `tenure_months` | Subscription tenure in months |
| `contract_type` | Month-to-month, one-year, or two-year |
| `internet_service` | Demonstration service category |
| `monthly_charges` | Synthetic recurring charge |
| `support_tickets_last_90d` | Indicator for one or more recent support tickets |
| `churned` | 1 = ended subscription in the synthetic sample; 0 = retained |

## Metrics and method
The script compares churn share by segment, aggregates tenure bands, and exports segment tables. Churn rate is the mean of the binary `churned` flag within a segment. This is exploratory segmentation, not a predictive model and not causal evidence.

## Run
From the repository root: `python projects/04_customer_churn/analysis.py`

Outputs include CSV segment summaries and a churn-by-contract chart.

## Suggested next steps
Validate definitions and labels against real business processes; examine customer acquisition cohorts and time-to-event; assess segment sizes; then test retention interventions with a suitable experimental or quasi-experimental design.

## Limitations
The synthetic label is intentionally rule-shaped, so patterns in this sample are baked into its construction. Results cannot support real targeting decisions, claims of causation, or forecasts. Real customer analysis should include consent, privacy, bias, and retention policy review.
