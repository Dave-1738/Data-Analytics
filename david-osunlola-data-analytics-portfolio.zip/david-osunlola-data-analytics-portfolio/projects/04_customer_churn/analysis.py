"""Exploratory churn segmentation on an entirely synthetic customer dataset."""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

PROJECT = Path(__file__).resolve().parent
DATA = PROJECT / "data" / "customers.csv"
OUT = PROJECT / "outputs"


def main():
    df = pd.read_csv(DATA)
    required = {"customer_id", "tenure_months", "contract_type", "internet_service", "monthly_charges", "support_tickets_last_90d", "churned"}
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")
    if df.customer_id.duplicated().any() or not set(df.churned.unique()).issubset({0, 1}):
        raise ValueError("Customer IDs must be unique and churned must be binary.")
    df["tenure_band"] = pd.cut(df.tenure_months, bins=[0, 12, 24, 48, 72], labels=["0–12", "13–24", "25–48", "49–72"], include_lowest=True)
    OUT.mkdir(exist_ok=True)
    for field in ["contract_type", "internet_service", "tenure_band", "support_tickets_last_90d"]:
        summary = df.groupby(field, observed=False, dropna=False).agg(customers=("customer_id", "count"), churned=("churned", "sum"), churn_rate=("churned", "mean")).reset_index()
        summary.to_csv(OUT / f"churn_by_{field}.csv", index=False, float_format="%.3f")
    contract = pd.read_csv(OUT / "churn_by_contract_type.csv")
    ax = contract.plot(x="contract_type", y="churn_rate", kind="bar", legend=False, figsize=(8, 5), title="Synthetic churn share by contract")
    ax.set_ylabel("Churn share"); ax.set_xlabel(""); ax.set_ylim(0, 1); ax.grid(axis="y", alpha=.25)
    plt.xticks(rotation=15, ha="right"); plt.tight_layout(); plt.savefig(OUT / "churn_by_contract.png", dpi=160); plt.close()
    print(f"Segmented {len(df)} synthetic customers. Outputs: {OUT}")

if __name__ == "__main__":
    main()
