# 03 · Payroll Cost & Reconciliation

## Business question
How do gross wages, deductions, and net pay trend by department and pay period, and do the records reconcile arithmetically?

## Dataset
`data/payroll.csv` contains 390 synthetic payroll rows for 30 fictional employee IDs across 13 pay dates. Amounts are invented demonstration values, not an Ontario payroll calculation or a statement of statutory rates.

## Metrics and method
The script checks that `gross_pay` equals regular pay + overtime + bonus and that net pay equals gross pay less listed deductions. It summarizes gross and net pay by period and department, and exports rows that fail arithmetic checks. The checks do **not** validate tax withholding, CPP/EI eligibility, annual maximums, taxable benefits, remittance timing, or legal compliance.

## Run
From the repository root: `python projects/03_payroll_analytics/analysis.py`

Outputs: pay period and department summaries, a reconciliation exception file, and gross pay trend chart.

## Responsible use and limitations
This project is a data-quality and reporting demonstration only. Real Canadian payroll requires current authoritative rules, employee-specific elections, year-to-date balances, and a properly maintained payroll system. Never use this sample or script to calculate or pay actual employees. Keep payroll data access limited and use approved secure storage.
