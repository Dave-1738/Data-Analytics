"""Payroll reporting and arithmetic reconciliation using synthetic records only."""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

PROJECT = Path(__file__).resolve().parent
DATA = PROJECT / "data" / "payroll.csv"
OUT = PROJECT / "outputs"


def main():
    df = pd.read_csv(DATA, parse_dates=["pay_date"])
    required = {"payroll_record_id", "pay_date", "employee_id", "department", "regular_pay", "overtime_pay", "bonus", "gross_pay", "income_tax", "cpp", "ei", "other_deductions", "net_pay"}
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")
    if df.payroll_record_id.duplicated().any():
        raise ValueError("Duplicate payroll record IDs found.")
    earning_sum = df[["regular_pay", "overtime_pay", "bonus"]].sum(axis=1).round(2)
    deduction_sum = df[["income_tax", "cpp", "ei", "other_deductions"]].sum(axis=1).round(2)
    df["gross_check_delta"] = (df.gross_pay - earning_sum).round(2)
    df["net_check_delta"] = (df.net_pay - (df.gross_pay - deduction_sum)).round(2)
    exceptions = df[df.gross_check_delta.abs().gt(.01) | df.net_check_delta.abs().gt(.01)]
    OUT.mkdir(exist_ok=True)
    exceptions.to_csv(OUT / "reconciliation_exceptions.csv", index=False)
    by_period = df.groupby("pay_date", as_index=False).agg(employee_records=("employee_id", "count"), gross_pay=("gross_pay", "sum"), net_pay=("net_pay", "sum"), deductions=("income_tax", "sum"))
    by_period.to_csv(OUT / "pay_period_summary.csv", index=False, float_format="%.2f")
    by_dept = df.groupby("department", as_index=False).agg(gross_pay=("gross_pay", "sum"), net_pay=("net_pay", "sum"), record_count=("employee_id", "count"))
    by_dept.to_csv(OUT / "department_summary.csv", index=False, float_format="%.2f")
    ax = by_period.plot(x="pay_date", y="gross_pay", marker="o", figsize=(10, 5), legend=False, title="Synthetic gross payroll by pay date")
    ax.set_ylabel("Amount (currency units)"); ax.set_xlabel("Pay date"); ax.grid(alpha=.25)
    plt.xticks(rotation=45, ha="right"); plt.tight_layout(); plt.savefig(OUT / "gross_pay_trend.png", dpi=160); plt.close()
    print(f"Reviewed {len(df)} synthetic records; arithmetic exceptions: {len(exceptions)}. Outputs: {OUT}")

if __name__ == "__main__":
    main()
