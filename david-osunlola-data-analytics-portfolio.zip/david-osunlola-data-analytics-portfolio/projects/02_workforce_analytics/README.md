# 02 · Workforce & HR Analytics

## Business question
How do hiring, exits, tenure, and workforce composition vary by department, location, and career level?

## Dataset
`data/workforce.csv` is a synthetic snapshot of 120 fictional workers. Employee IDs are generated labels; no real personal information is included.

| Field | Description |
|---|---|
| `employee_id` | Synthetic record key; not a real identifier |
| `department`, `location` | Organizational group and work location |
| `hire_date`, `exit_date` | Employment dates; blank exit date means active at the snapshot |
| `annual_salary` | Synthetic annualized salary |
| `career_level`, `employment_type` | Broad workforce attributes |

## Metrics and method
The analysis calculates snapshot headcount, exits during the sample window, average tenure, salary distribution, and department-level exit share. Exit share is presented as a descriptive proportion of records, **not** a formal period attrition rate: the dataset lacks monthly headcount denominators and complete employment histories.

## Run
From the repository root: `python projects/02_workforce_analytics/analysis.py`

Outputs include summary CSVs and a department headcount chart. SQL examples are available in `sql/`.

## Responsible use
Workforce analytics can affect people. Use aggregated reporting, minimum group sizes, access controls, and documented definitions. Do not use these synthetic results to make employment decisions. Before analyzing real workforce data, confirm a lawful purpose, appropriate access, data minimization, and fairness review. Small-group results can reveal individual information even when names are removed.

## Limitations
Synthetic sample, one snapshot, no FTE adjustment, missing demographic and movement detail, and no validated business context. Salary comparisons are not adjusted for role scope, experience, location, or hours.
