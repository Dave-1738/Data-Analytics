"""Descriptive workforce analytics on a synthetic, anonymized demonstration file."""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

PROJECT = Path(__file__).resolve().parent
DATA = PROJECT / "data" / "workforce.csv"
OUT = PROJECT / "outputs"


def main():
    df = pd.read_csv(DATA, parse_dates=["hire_date", "exit_date"])
    required = {"employee_id", "department", "location", "hire_date", "exit_date", "annual_salary", "career_level", "employment_type"}
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")
    if df.employee_id.duplicated().any() or df.annual_salary.lt(0).any():
        raise ValueError("Duplicate employee IDs or negative salary found.")
    snapshot = pd.Timestamp("2025-12-31")
    df["is_active"] = df.exit_date.isna() | df.exit_date.gt(snapshot)
    df["tenure_years"] = ((df.exit_date.fillna(snapshot) - df.hire_date).dt.days / 365.25).clip(lower=0)
    df["exited_in_sample"] = df.exit_date.notna() & df.exit_date.le(snapshot)
    OUT.mkdir(exist_ok=True)
    summary = df.groupby("department", as_index=False).agg(records=("employee_id", "count"), active_headcount=("is_active", "sum"), exits_in_sample=("exited_in_sample", "sum"), avg_tenure_years=("tenure_years", "mean"), median_salary=("annual_salary", "median"))
    summary["exit_share_of_records"] = summary.exits_in_sample / summary.records
    summary.to_csv(OUT / "department_summary.csv", index=False, float_format="%.2f")
    by_level = df.groupby("career_level", as_index=False).agg(records=("employee_id", "count"), median_salary=("annual_salary", "median"), avg_tenure_years=("tenure_years", "mean"))
    by_level.to_csv(OUT / "career_level_summary.csv", index=False, float_format="%.2f")
    ax = summary.plot(x="department", y="active_headcount", kind="bar", legend=False, figsize=(9, 5), title="Active headcount by department")
    ax.set_ylabel("Synthetic headcount"); ax.set_xlabel(""); ax.grid(axis="y", alpha=.25)
    plt.xticks(rotation=25, ha="right"); plt.tight_layout(); plt.savefig(OUT / "headcount_by_department.png", dpi=160); plt.close()
    print(f"Analyzed {len(df)} synthetic records. Outputs: {OUT}")

if __name__ == "__main__":
    main()
