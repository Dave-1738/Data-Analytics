"""Retail sales and profitability analysis on the included synthetic dataset."""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[2]
PROJECT = Path(__file__).resolve().parent
DATA = PROJECT / "data" / "sales.csv"
OUT = PROJECT / "outputs"


def main():
    df = pd.read_csv(DATA, parse_dates=["order_date"])
    required = {"order_id", "order_date", "region", "category", "product", "units_sold", "unit_price", "unit_cost"}
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")
    if df[list(required)].isna().any().any() or (df["units_sold"] < 0).any():
        raise ValueError("Required data contains nulls or negative units.")
    df["revenue"] = df.units_sold * df.unit_price
    df["cogs"] = df.units_sold * df.unit_cost
    df["gross_profit"] = df.revenue - df.cogs
    df["gross_margin"] = df.gross_profit.div(df.revenue.where(df.revenue.ne(0)))
    df["month"] = df.order_date.dt.to_period("M").astype(str)
    OUT.mkdir(exist_ok=True)
    for group, name in [("month", "monthly"), ("category", "category"), ("region", "region")]:
        summary = df.groupby(group, as_index=False).agg(orders=("order_id", "nunique"), units=("units_sold", "sum"), revenue=("revenue", "sum"), gross_profit=("gross_profit", "sum"))
        summary["gross_margin"] = summary.gross_profit.div(summary.revenue.where(summary.revenue.ne(0)))
        summary.to_csv(OUT / f"{name}_summary.csv", index=False, float_format="%.2f")
    monthly = pd.read_csv(OUT / "monthly_summary.csv")
    ax = monthly.plot(x="month", y=["revenue", "gross_profit"], marker="o", figsize=(10, 5), title="Monthly revenue and gross profit")
    ax.set_ylabel("Amount (currency units)"); ax.set_xlabel("Month"); ax.grid(alpha=.25)
    plt.xticks(rotation=45, ha="right"); plt.tight_layout(); plt.savefig(OUT / "monthly_trend.png", dpi=160); plt.close()
    print(f"Analyzed {len(df)} order lines. Outputs: {OUT.relative_to(ROOT)}")

if __name__ == "__main__":
    main()
