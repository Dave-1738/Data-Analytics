# 01 · Retail Sales & Profitability

## Business question
Which product categories, products, regions, and months are contributing most to sales and gross profit?

## Dataset
`data/sales.csv` contains 96 synthetic order lines across 2025. Values are generated for this portfolio and are not real transactions.

| Field | Description |
|---|---|
| `order_id` | Demonstration order identifier |
| `order_date` | Order date (ISO format) |
| `region` | Sales region |
| `category`, `product` | Product grouping and item |
| `units_sold` | Units on the line |
| `unit_price`, `unit_cost` | Per-unit sale price and cost |

## Metrics and method
- **Revenue** = units sold × unit price
- **Cost of goods sold** = units sold × unit cost
- **Gross profit** = revenue − cost of goods sold
- **Gross margin** = gross profit ÷ revenue

The script validates required columns, derives line-level metrics, summarizes by month/category/region, and plots monthly revenue and gross profit.

## Run
From the repository root: `python projects/01_retail_sales/analysis.py`

Outputs are written to `outputs/` and include monthly, category, and regional CSV summaries plus a PNG trend chart. The `sql/` folder contains equivalent SQLite-compatible query examples.

## Suggested business follow-up
Compare category margin alongside revenue before prioritizing promotions. Investigate low-margin, high-revenue products and check whether seasonal sales patterns repeat in later periods.

## Limitations
The sample is deliberately small and synthetic. It omits returns, discount allocation, tax, shipping, channel, and inventory constraints; findings should not be generalized to a real retailer.
