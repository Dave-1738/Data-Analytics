# David Osunlola | Data Analytics Portfolio

A curated collection of practical, end-to-end analytics projects showing how I turn business questions into clean data, useful metrics, and clear recommendations. The portfolio combines Python, SQL, Excel-ready CSVs, and dashboard planning across sales, people analytics, payroll, customer retention, and inventory operations.

> **Portfolio note:** All included records are synthetic and created for demonstration. They do not represent real customers, employees, employers, or payroll records. Project findings are illustrative, not claims about a real organization.

## Portfolio at a glance

| Project | Business question | Tools | Deliverables |
|---|---|---|---|
| [Retail Sales & Profitability](projects/01_retail_sales/README.md) | Which products, regions, and periods contribute most to revenue and gross profit? | Python, pandas, SQL, Excel/Power BI-ready outputs | KPI tables, trend chart, SQL analysis |
| [Workforce & HR Analytics](projects/02_workforce_analytics/README.md) | How are hiring, attrition, tenure, and representation changing across teams? | Python, pandas, SQL, Excel/Power BI-ready outputs | Workforce metrics, attrition cuts, privacy and fairness notes |
| [Payroll Cost & Reconciliation](projects/03_payroll_analytics/README.md) | How do gross pay, deductions, and employer costs vary by pay period and department? | Python, pandas, SQL, Excel | Reconciliation summary, exception review, metric definitions |
| [Customer Churn & Retention](projects/04_customer_churn/README.md) | Which customer groups show higher churn, and where could retention work focus? | Python, pandas, Excel/Power BI-ready outputs | Churn segments, retention recommendations, caveats |
| [Inventory & Replenishment](projects/05_inventory_optimization/README.md) | Which products account for the most demand and may need replenishment attention? | Python, pandas, SQL, Excel | ABC classification, stock-cover indicators, action list |

## Start here

1. Choose a project and read its `README.md` for the business context, definitions, and limitations.
2. Use Python 3.10 or later. From the repository root, install the shared dependencies:
   ```bash
   python -m pip install -r requirements.txt
   ```
3. Run a project's analysis script from the repository root, for example:
   ```bash
   python projects/01_retail_sales/analysis.py
   ```
4. Find generated tables and charts in that project's `outputs/` directory. Outputs are reproducible from the included CSVs.

Each project is self-contained. CSVs can also be opened in Excel or loaded into Power BI. SQL examples use standard SQLite-compatible syntax and can be run against the corresponding CSV data after import.

## Repository structure

```text
.
├── projects/
│   ├── 01_retail_sales/
│   ├── 02_workforce_analytics/
│   ├── 03_payroll_analytics/
│   ├── 04_customer_churn/
│   └── 05_inventory_optimization/
├── requirements.txt
├── LICENSE
└── README.md
```

## Skills demonstrated

- Translating an operational question into measurable KPIs
- Data inspection, validation, transformation, and aggregation
- Exploratory analysis and segment comparisons
- SQL joins, grouping, conditional aggregation, and window functions
- Clear charts, concise findings, and practical next steps
- Responsible treatment of workforce and payroll data
- Documenting assumptions, definitions, and analytical limitations

## About

I’m David Osunlola, a data analytics professional with a business and HR background and hands-on experience in payroll accounting, operations, and IT support. I’m interested in analytics roles where reliable reporting and thoughtful analysis help teams make better decisions.

- **GitHub:** [@Dave-1738](https://github.com/Dave-1738)
- **LinkedIn:** [David Osunlola](https://www.linkedin.com/in/david-osunlola/)

## Roadmap

- Add interactive Power BI dashboards and screenshots as each project is developed.
- Extend the customer retention work with model evaluation and explainability.
- Add source notes and refresh dates when using external public datasets.

## License

Code and documentation are released under the MIT License. The synthetic sample data are provided for educational and portfolio demonstration use; see each project's data notes.
